from .app import koreapp

def kore_parent_configure(args):
    koreapp.configure(args)

def kore_worker_configure():
    return
